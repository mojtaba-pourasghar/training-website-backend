package ir.brandimo.training.shop.entity;

public class Payment {
}
